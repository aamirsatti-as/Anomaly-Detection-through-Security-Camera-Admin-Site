import React from "react";
import '../admin/admin.css';
import { Route, Router, Routes } from "react-router-dom";
import Navbar from "../component/Navbar";
const Admin = () => {
  return (
    <>

<div class="bg-city py-md-8 text-white" style={{backgroundColoe:'red'}}>
  <div class="container py-6 px-4">
    <div class="row">

      <div class="col-md-12 pb-md-5">
        <h1 class="display-4 display-md-2 font-weight-bold text-right">Smart &amp; efficient surveillance</h1>
      </div>

      <div class="row justify-content-end align-items-top pt-md-5 mx-3">
        <div class="col-md-8 col-12 pt-5 pt-md-8 px-0 pr-md-5 order-2 order-md-1">
          <p class="lead">
            <span class="text-white">Our algorithm monitors video feeds in real time and alerts security personnel of violent incidents, car crashes, perimeter breach, or other incidents.</span>
            <span class="text-lightgray text-dark-shadow">Up to thousands of feeds at once, with a detection speed of less than half a second.</span>
          </p>
        </div>
        <div class="col-12 col-md-4 pt-5 pt-md-8 px-0 pl-md-5 text-center order-1 order-md-2">
          <p class="display-6 font-weight-bold text-white">incident detected in</p>
          <p class="display-1 font-weight-bold text-white mb-0">
            {/* <small><img src="/img/navigate_before-80px-white.svg" alt="Less than"/></small>0.5<small>s</small> */}
          </p>
        </div>
      </div>
    </div>

    <div class="row justify-content-start p-3 pt-5">
      <div>
        <a href="/product" class="btn btn-primary btn-lg font-family-mono">
          <span>Discover our products</span>
          {/* <img src="/img/arrow_forward-24px-white.svg" alt="Arrow forward icon" style={{marginTop: '3px'}}/> */}
        </a>
      </div>
    </div>
  </div>
</div>

      
    </>
  );
};

export default Admin;
