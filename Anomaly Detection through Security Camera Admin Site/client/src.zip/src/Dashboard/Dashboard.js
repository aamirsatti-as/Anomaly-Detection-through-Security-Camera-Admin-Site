import React from 'react'
import './Dashboard.css'
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import login from '../Login/login';
import img from '../images/main.jpg'
import Navbar from '../component/Navbar';
import add from '../images/add.png'
import view from '../images/view.png'
import viewDete from '../images/viewdet.png'
import password from '../images/password.png'
export const Landing = () => {
  function onPressbtn() {
    <Router>
      <Routes>
        <Route path="D:\frontend\src\component\login.js" component={login} />
      </Routes>
    </Router>

  }
  return (
    <>
    <div>
        <Navbar />
    </div>
    <div>
    <img className="bkimage" src="../images/image.webp"></img> 
    </div>

  {/* <img className='dcr' src={img}></img> */}
{/*   
    <div>
    <div className="row small-up-1 medium-up-1 large-up-1 center  ">
              <h1>How It Works</h1>
                <div className="column aos-init aos-animate" data-aos="fade-up" data-aos-delay="250">
                  <div className="card">
                    {/* <figure className="image image-icon"><img width="1024" height="1024" src="https://actuate.ai/wp-content/uploads/2019/09/case-studies.svg" className="attachment-large size-large" alt="" loading="lazy"/></figure>							 }
                    <div className="card-body ">
                      <h5>Deep Learning Algorithms</h5>

                      <p>Actuate's AI technology uses a convolutional neural network (CNN) to replicate how a human brain would process information.</p>

                    </div>
                  </div>
                </div>

                <div className="column aos-init aos-animate" data-aos="fade-up" data-aos-delay="500">
                  <div className="card">
                    {/* <figure className="image image-icon">
              <img width="1024" height="1024" src="https://actuate.ai/wp-content/uploads/2019/09/explore-benefits-1.svg" className="attachment-large size-large" alt="" loading="lazy"/></figure>					 }
                    <div className="card-body ">
                      <h5>Cutting-Edge Data Science</h5>

                      <p>The CNN is trained to recognize weapons from hundreds of thousands of images in a proprietary data set.</p>

                    </div>
                  </div>
                </div>

                <div className="column aos-init aos-animate" data-aos="fade-up" data-aos-delay="750">
                  <div className="card">
                    {/* <figure className="image image-icon"><img width="1024" height="1024" src="https://actuate.ai/wp-content/uploads/2019/09/accuracy.svg" className="attachment-large size-large" alt="" loading="lazy"/></figure>		 }
                    <div className="card-body ">
                      <h5>Unparalleled Accuracy</h5>

                      <p>The system automatically identifies weapons in camera footage instantly, with well over 99% detection accuracy within the first 5 seconds.</p>

                    </div>
                  </div>
                </div>

              </div>
      
    </div> */}
                
            

      <div>
      <div className='landingbody'>

<div className='bk' >
  {/* <img className='dcr' src={img}></img> */}

  <div className='center2'>
    <h1 className='heading' style={{ color: "navy", fontSize: 40, marginTop:'15px'}}>ADTSC</h1>
    <div className='tags'>
      <div className='images'>
      <Link to="/notifiers" style={{ textDecoration: "none" }}>
        <img className='circleimage' src={add} alt=''></img>
        <text className='headingtext' style={{width:'110px',fontWeight:'bold'}}>Add Notifier</text>
      </Link>
      </div>

      <div className='images'>
        <Link to="/viewnotifiers" style={{ textDecoration: "none" }}>
          <img className='circleimage' src={view} alt=''></img>
          <text className='headingtext'style={{width:'115px',fontWeight:'bold'}}>View Notifiers</text>
        </Link>
      </div>

      <div className='images'>
        <Link to="/viewdetection" style={{ textDecoration: "none" }}>
          <img className='circleimage' src={viewDete} alt=''></img>
          <text className='headingtext' style={{width:'125px',fontWeight:'bold'}}>View Detection</text>
        </Link>
      </div>

      <div className='images'>
        <Link to="/changepassword" style={{ textDecoration: "none" }}>
          <img className='circleimage' src={password} alt=''></img>
          <text className='headingtext' style={{width:'150px',fontWeight:'bold'}}>Change Password</text>
        </Link>
      </div>


      {/* <div className='images'>
<Link to="/loginpatient" style={{textDecoration: "none"}}>
<img className= 'circleimage' src='/images/patient.png' alt=''></img>
<text className='headingtext' >Patient</text>

{/* <button className='btn'>Patient</button> }</Link> 
</div> */}

    </div>
  </div>
</div>
</div>

      </div>
      </>

  )
}
export default Landing;